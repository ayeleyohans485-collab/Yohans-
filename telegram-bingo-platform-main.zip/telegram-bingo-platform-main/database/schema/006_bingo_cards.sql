CREATE TABLE bingo_cards (
    id SERIAL PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ticket_id INTEGER REFERENCES tickets(id) ON DELETE CASCADE,
    numbers JSONB NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bingo_cards_game_id ON bingo_cards(game_id);
CREATE INDEX idx_bingo_cards_user_id ON bingo_cards(user_id);
CREATE INDEX idx_bingo_cards_ticket_id ON bingo_cards(ticket_id);
