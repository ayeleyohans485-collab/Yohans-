const pool = require("../config/database");

class BingoCard {
  static async createCard({ game_id, user_id, ticket_id, numbers }, client = pool) {
    const result = await client.query(
      `
      INSERT INTO bingo_cards
      (
        game_id,
        user_id,
        ticket_id,
        numbers
      )
      VALUES ($1, $2, $3, $4)
      RETURNING *
      `,
      [game_id, user_id, ticket_id, JSON.stringify(numbers)]
    );

    return result.rows[0];
  }

  static async findByTicket(ticket_id) {
    const result = await pool.query(
      `
      SELECT *
      FROM bingo_cards
      WHERE ticket_id = $1
      `,
      [ticket_id]
    );

    return result.rows;
  }

  static async findByUser(user_id) {
    const result = await pool.query(
      `
      SELECT *
      FROM bingo_cards
      WHERE user_id = $1
      ORDER BY id DESC
      `,
      [user_id]
    );

    return result.rows;
  }

  static async deleteCard(id) {
    const result = await pool.query(
      `
      DELETE FROM bingo_cards
      WHERE id = $1
      RETURNING *
      `,
      [id]
    );

    return result.rows[0];
  }
}

module.exports = BingoCard;