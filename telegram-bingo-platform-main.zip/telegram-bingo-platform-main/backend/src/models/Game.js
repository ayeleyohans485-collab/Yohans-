const pool = require("../config/database");

class Game {
  static async _getColumns() {
    if (this.columnsCache) {
      return this.columnsCache;
    }

    const result = await pool.query(
      `
      SELECT column_name
      FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = $1
      `,
      ["games"]
    );

    this.columnsCache = new Set(result.rows.map((row) => row.column_name));
    return this.columnsCache;
  }

  static async create(payload = {}) {
    const columns = await this._getColumns();
    const fields = [];
    const values = [];

    const addField = (field, value) => {
      if (columns.has(field)) {
        fields.push(field);
        values.push(value);
      }
    };

    addField("name", payload.name);
    addField("description", payload.description || null);
    addField("entry_fee", payload.entry_fee);
    addField("prize", payload.prize);
    addField("max_players", payload.max_players);
    addField("current_players", payload.current_players ?? 0);
    addField("game_type", payload.game_type || "classic");
    addField("start_time", payload.start_time || null);
    addField("end_time", payload.end_time || null);
    addField("status", payload.status || "pending");

    if (!fields.includes("name") || !fields.includes("entry_fee") || !fields.includes("prize") || !fields.includes("max_players")) {
      throw new Error("The games table is missing required columns for game creation");
    }

    const placeholders = fields.map((_, index) => `$${index + 1}`).join(", ");
    const query = `
      INSERT INTO games (${fields.join(", ")})
      VALUES (${placeholders})
      RETURNING *
    `;

    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async findAll() {
    const result = await pool.query(`
      SELECT *
      FROM games
      ORDER BY id DESC
    `);

    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query(
      `
      SELECT *
      FROM games
      WHERE id = $1
      `,
      [id]
    );

    return result.rows[0];
  }

  static async update(id, payload = {}) {
    const columns = await this._getColumns();
    const updates = Object.entries(payload).filter(([field]) => columns.has(field));

    if (!id) {
      const error = new Error("game id is required");
      error.statusCode = 400;
      throw error;
    }

    if (updates.length === 0) {
      return this.findById(id);
    }

    const setClause = updates.map(([field], index) => `${field} = $${index + 1}`).join(", ");
    const values = updates.map(([, value]) => value);

    const query = `
      UPDATE games
      SET ${setClause}, updated_at = CURRENT_TIMESTAMP
      WHERE id = $${updates.length + 1}
      RETURNING *
    `;

    const result = await pool.query(query, [...values, id]);
    return result.rows[0];
  }

  static async delete(id) {
    const result = await pool.query(
      `
      DELETE FROM games
      WHERE id = $1
      RETURNING *
      `,
      [id]
    );

    return result.rows[0];
  }

  static async getActiveGames() {
    const result = await pool.query(`
      SELECT *
      FROM games
      WHERE status = 'active'
      ORDER BY id DESC
    `);

    return result.rows;
  }

  static async getUpcomingGames() {
    const result = await pool.query(`
      SELECT *
      FROM games
      WHERE status = 'pending'
      ORDER BY COALESCE(start_time, created_at) ASC, id DESC
    `);

    return result.rows;
  }

  static async incrementPlayers(id, amount = 1) {
    const columns = await this._getColumns();

    if (columns.has("current_players")) {
      const result = await pool.query(
        `
        UPDATE games
        SET current_players = COALESCE(current_players, 0) + $1,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
        RETURNING *
        `,
        [Number(amount), id]
      );

      return result.rows[0];
    }

    // If the column doesn't exist in the schema, update only the timestamp and return the game
    await pool.query(
      `
      UPDATE games
      SET updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      `,
      [id]
    );

    return this.findById(id);
  }
}

module.exports = Game;