const pool = require("../config/database");

class Ticket {
  static async create({ game_id, user_id, price = 0.00, status = "active" }, client = pool) {
    const result = await client.query(
      `
      INSERT INTO tickets
      (
        game_id,
        user_id,
        price,
        status
      )
      VALUES ($1, $2, $3, $4)
      RETURNING *
      `,
      [game_id, user_id, price, status]
    );

    return result.rows[0];
  }

  static async findByUser(user_id) {
    const result = await pool.query(
      `
      SELECT *
      FROM tickets
      WHERE user_id = $1
      ORDER BY id DESC
      `,
      [user_id]
    );

    return result.rows;
  }

  static async findByGame(game_id) {
    const result = await pool.query(
      `
      SELECT *
      FROM tickets
      WHERE game_id = $1
      ORDER BY id DESC
      `,
      [game_id]
    );

    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query(
      `
      SELECT *
      FROM tickets
      WHERE id = $1
      `,
      [id]
    );

    return result.rows[0];
  }

  static async updateStatus(id, status, client = pool) {
    const result = await client.query(
      `
      UPDATE tickets
      SET status = $1
      WHERE id = $2
      RETURNING *
      `,
      [status, id]
    );

    return result.rows[0];
  }
}

module.exports = Ticket;
