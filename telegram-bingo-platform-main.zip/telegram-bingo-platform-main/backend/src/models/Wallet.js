const pool = require("../config/database");

class Wallet {
    static async create(user_id, data = {}) {
        const {
            balance = 0.0,
            currency = "ETB",
            status = "active"
        } = data;

        const result = await pool.query(
            `
            INSERT INTO wallets (user_id, balance, currency, status)
            VALUES ($1, $2, $3, $4)
            RETURNING *
            `,
            [user_id, balance, currency, status]
        );

        return result.rows[0];
    }

    static async findById(id) {
        const result = await pool.query(
            `
            SELECT *
            FROM wallets
            WHERE id = $1
            `,
            [id]
        );

        return result.rows[0];
    }

    static async findByUserId(user_id) {
       const result = await client.query(
            `
            SELECT *
            FROM wallets
            WHERE user_id = $1
            `,
            [user_id]
        );

        return result.rows[0];
    }

    static async update(user_id, data, client = pool) {
        const fields = [];
        const values = [];
        let index = 1;

        Object.entries(data).forEach(([key, value]) => {
            if (value !== undefined) {
                fields.push(`${key} = $${index}`);
                values.push(value);
                index += 1;
            }
        });

        if (fields.length === 0) {
            return this.findByUserId(user_id);
        }

        values.push(user_id);

        const result = await client.query(
            `
            UPDATE wallets
            SET ${fields.join(", ")}, updated_at = CURRENT_TIMESTAMP
            WHERE user_id = $${index}
            RETURNING *
            `,
            values
        );

        return result.rows[0];
    }

    static async updateBalance(user_id, amount, client = pool) {
        const result = await client.query(
            `
            UPDATE wallets
            SET balance = balance + $1,
                updated_at = CURRENT_TIMESTAMP
            WHERE user_id = $2
            RETURNING *
            `,
            [amount, user_id]
        );

        return result.rows[0];
    }
}

module.exports = Wallet;