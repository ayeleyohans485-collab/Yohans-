const pool = require("../config/database");


class User {

    static async create({
        telegram_id,
        username,
        first_name,
        phone
    }) {

        const result = await pool.query(
            `
            INSERT INTO users
            (
                telegram_id,
                username,
                first_name,
                phone
            )
            VALUES ($1,$2,$3,$4)
            RETURNING *
            `,
            [
                telegram_id,
                username,
                first_name,
                phone
            ]
        );

        return result.rows[0];
    }

    static async findById(id) {
        const result = await pool.query(
            `
            SELECT *
            FROM users
            WHERE id=$1
            `,
            [id]
        );

        return result.rows[0];
    }

    static async findByTelegramId(telegram_id) {

        const result = await pool.query(
            `
            SELECT *
            FROM users
            WHERE telegram_id=$1
            `,
            [telegram_id]
        );

        return result.rows[0];
    }

    static async findAll() {

        const result = await pool.query(
            `
            SELECT *
            FROM users
            ORDER BY id DESC
            `
        );

        return result.rows;
    }

    static async update(id, data) {
        const fields = [];
        const values = [];
        let index = 1;

        Object.entries(data).forEach(([key, value]) => {
            if (value !== undefined) {
                fields.push(`${key} = $${index}`);
                values.push(value);
                index += 1;
            }
        });

        if (fields.length === 0) {
            return this.findById(id);
        }

        values.push(id);

        const result = await pool.query(
            `
            UPDATE users
            SET ${fields.join(", ")}, updated_at = CURRENT_TIMESTAMP
            WHERE id = $${index}
            RETURNING *
            `,
            values
        );

        return result.rows[0];
    }

    static async delete(id) {
        const result = await pool.query(
            `
            DELETE FROM users
            WHERE id=$1
            RETURNING *
            `,
            [id]
        );

        return result.rows[0];
    }

}


module.exports = User;