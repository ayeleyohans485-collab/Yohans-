const pool = require("../config/database");


class Transaction {


    static async create({
        user_id,
        type,
        amount,
        reference,
        status
    }, client = pool){

        const result = await client.query(
            `
            INSERT INTO transactions
            (
                user_id,
                type,
                amount,
                reference,
                status
            )
            VALUES ($1,$2,$3,$4,$5)
            RETURNING *
            `,
            [
                user_id,
                type,
                amount,
                reference,
                status
            ]
        );


        return result.rows[0];

    }



    static async findByUser(user_id){

        const result = await pool.query(
            `
            SELECT *
            FROM transactions
            WHERE user_id=$1
            ORDER BY id DESC
            `,
            [user_id]
        );


        return result.rows;

    }


}


module.exports = Transaction;