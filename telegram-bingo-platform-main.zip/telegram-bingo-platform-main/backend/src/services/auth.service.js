const User = require("../models/User");
const Wallet = require("../models/Wallet");

class AuthService {
    static async registerTelegramUser(data) {
        const telegramId = Number(data?.telegram_id);

        if (!Number.isInteger(telegramId) || telegramId <= 0) {
            const error = new Error("A valid telegram_id is required");
            error.statusCode = 400;
            throw error;
        }

        const existingUser = await User.findByTelegramId(telegramId);

        if (existingUser) {
            return {
                user: existingUser,
                created: false
            };
        }

        const user = await User.create({
            ...data,
            telegram_id: telegramId
        });

        await Wallet.create(user.id);

        return {
            user,
            created: true
        };
    }

    static async getUserProfile(telegramId) {
        const normalizedTelegramId = Number(telegramId);

        if (!Number.isInteger(normalizedTelegramId) || normalizedTelegramId <= 0) {
            const error = new Error("A valid telegram_id is required");
            error.statusCode = 400;
            throw error;
        }

        return User.findByTelegramId(normalizedTelegramId);
    }
}

module.exports = AuthService;