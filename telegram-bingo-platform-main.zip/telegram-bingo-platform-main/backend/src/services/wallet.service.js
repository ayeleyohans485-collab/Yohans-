const Wallet = require("../models/Wallet");
const Transaction = require("../models/Transaction");

class WalletService {
    static async deposit(user_id, amount, reference) {
        const normalizedAmount = Number(amount);

        if (!Number.isFinite(normalizedAmount) || normalizedAmount <= 0) {
            const error = new Error("A positive amount is required for deposit");
            error.statusCode = 400;
            throw error;
        }

        const wallet = await Wallet.updateBalance(user_id, normalizedAmount);

        await Transaction.create({
            user_id,
            type: "deposit",
            amount: normalizedAmount,
            reference,
            status: "completed"
        });

        return wallet;
    }

    static async withdraw(user_id, amount, reference) {
        const normalizedAmount = Number(amount);

        if (!Number.isFinite(normalizedAmount) || normalizedAmount <= 0) {
            const error = new Error("A positive amount is required for withdrawal");
            error.statusCode = 400;
            throw error;
        }

        const wallet = await Wallet.findByUserId(user_id);

        if (!wallet) {
            const error = new Error("Wallet not found");
            error.statusCode = 404;
            throw error;
        }

        if (Number(wallet.balance) < normalizedAmount) {
            const error = new Error("Insufficient wallet balance");
            error.statusCode = 400;
            throw error;
        }

        const updatedWallet = await Wallet.updateBalance(user_id, -normalizedAmount);

        await Transaction.create({
            user_id,
            type: "withdraw",
            amount: normalizedAmount,
            reference,
            status: "completed"
        });

        return updatedWallet;
    }

    static async getBalance(user_id) {
        const wallet = await Wallet.findByUserId(user_id);

        if (!wallet) {
            const error = new Error("Wallet not found");
            error.statusCode = 404;
            throw error;
        }

        return wallet;
    }

    static async getTransactionHistory(user_id) {
        const wallet = await Wallet.findByUserId(user_id);

        if (!wallet) {
            const error = new Error("Wallet not found");
            error.statusCode = 404;
            throw error;
        }

        return Transaction.findByUser(user_id);
    }
}

module.exports = WalletService;