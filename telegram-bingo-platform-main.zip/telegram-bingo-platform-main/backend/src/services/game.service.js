const Game = require("../models/Game");

class GameService {
  static VALID_STATUSES = ["pending", "active", "completed", "cancelled"];

  static async createGame(payload) {
    const normalized = this._normalizePayload(payload);

    if (!normalized.name) {
      const error = new Error("name is required");
      error.statusCode = 400;
      throw error;
    }

    if (normalized.entry_fee === undefined || normalized.entry_fee === null) {
      const error = new Error("entry_fee is required");
      error.statusCode = 400;
      throw error;
    }

    if (normalized.prize === undefined || normalized.prize === null) {
      const error = new Error("prize is required");
      error.statusCode = 400;
      throw error;
    }

    if (normalized.max_players === undefined || normalized.max_players === null) {
      const error = new Error("max_players is required");
      error.statusCode = 400;
      throw error;
    }

    return Game.create(normalized);
  }

  static async getGames() {
    return Game.findAll();
  }

  static async getGame(id) {
    if (!id) {
      const error = new Error("game id is required");
      error.statusCode = 400;
      throw error;
    }

    const game = await Game.findById(id);

    if (!game) {
      const error = new Error("Game not found");
      error.statusCode = 404;
      throw error;
    }

    return game;
  }

  static async updateGame(id, payload) {
    const game = await this.getGame(id);
    const normalized = this._normalizePayload(payload, game);

    if (Object.keys(normalized).length === 0) {
      const error = new Error("No valid fields provided for update");
      error.statusCode = 400;
      throw error;
    }

    return Game.update(id, normalized);
  }

  static async deleteGame(id) {
    const game = await this.getGame(id);
    return Game.delete(id, game);
  }

  static async activateGame(id) {
    const game = await this.getGame(id);

    if (game.status !== "pending") {
      const error = new Error("Only a pending game can be activated");
      error.statusCode = 400;
      throw error;
    }

    return Game.update(id, { status: "active" });
  }

  static async completeGame(id) {
    const game = await this.getGame(id);

    if (game.status !== "active") {
      const error = new Error("Only an active game can be completed");
      error.statusCode = 400;
      throw error;
    }

    return Game.update(id, { status: "completed" });
  }

  static async getActiveGames() {
    return Game.getActiveGames();
  }

  static async getUpcomingGames() {
    return Game.getUpcomingGames();
  }

  static _normalizePayload(payload = {}, existingGame = {}) {
    const normalized = {};
    const data = payload || {};

    if (data.name !== undefined) {
      const name = String(data.name).trim();
      if (!name) {
        const error = new Error("name cannot be empty");
        error.statusCode = 400;
        throw error;
      }
      normalized.name = name;
    }

    if (data.description !== undefined) {
      normalized.description = String(data.description).trim();
    }

    if (data.entry_fee !== undefined) {
      const entryFee = Number(data.entry_fee);
      if (!Number.isFinite(entryFee) || entryFee <= 0) {
        const error = new Error("entry_fee must be a positive number");
        error.statusCode = 400;
        throw error;
      }
      normalized.entry_fee = entryFee;
    }

    if (data.prize !== undefined) {
      const prize = Number(data.prize);
      if (!Number.isFinite(prize) || prize <= 0) {
        const error = new Error("prize must be a positive number");
        error.statusCode = 400;
        throw error;
      }
      normalized.prize = prize;
    }

    if (data.max_players !== undefined) {
      const maxPlayers = Number(data.max_players);
      if (!Number.isInteger(maxPlayers) || maxPlayers <= 0) {
        const error = new Error("max_players must be a positive integer");
        error.statusCode = 400;
        throw error;
      }
      normalized.max_players = maxPlayers;
    }

    if (data.current_players !== undefined) {
      const currentPlayers = Number(data.current_players);
      if (!Number.isInteger(currentPlayers) || currentPlayers < 0) {
        const error = new Error("current_players must be a non-negative integer");
        error.statusCode = 400;
        throw error;
      }
      normalized.current_players = currentPlayers;
    }

    if (data.game_type !== undefined) {
      normalized.game_type = String(data.game_type).trim() || "classic";
    }

    if (data.start_time !== undefined) {
      normalized.start_time = this._normalizeTimestamp(data.start_time);
    }

    if (data.end_time !== undefined) {
      normalized.end_time = this._normalizeTimestamp(data.end_time);
    }

    if (data.status !== undefined) {
      const status = String(data.status).trim().toLowerCase();
      if (!this.VALID_STATUSES.includes(status)) {
        const error = new Error("status must be one of: pending, active, completed, cancelled");
        error.statusCode = 400;
        throw error;
      }
      normalized.status = status;
    }

    const nextMaxPlayers = normalized.max_players ?? existingGame.max_players;
    const nextCurrentPlayers = normalized.current_players ?? existingGame.current_players ?? 0;

    if (nextMaxPlayers !== undefined && nextCurrentPlayers > nextMaxPlayers) {
      const error = new Error("current_players cannot exceed max_players");
      error.statusCode = 400;
      throw error;
    }

    if (normalized.start_time && normalized.end_time) {
      const startTime = new Date(normalized.start_time);
      const endTime = new Date(normalized.end_time);

      if (endTime <= startTime) {
        const error = new Error("end_time must be after start_time");
        error.statusCode = 400;
        throw error;
      }
    }

    return normalized;
  }

  static _normalizeTimestamp(value) {
    if (value === undefined || value === null || value === "") {
      return null;
    }

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      const error = new Error("Invalid date value");
      error.statusCode = 400;
      throw error;
    }

    return date.toISOString();
  }
}

module.exports = GameService;
