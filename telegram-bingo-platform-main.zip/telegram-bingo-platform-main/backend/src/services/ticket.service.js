const pool = require("../config/database");
const Ticket = require("../models/Ticket");
const BingoCard = require("../models/BingoCard");

class TicketService {
  static generateBingoCard() {
    const columns = [
      Array.from({ length: 15 }, (_, index) => index + 1),
      Array.from({ length: 15 }, (_, index) => index + 16),
      Array.from({ length: 15 }, (_, index) => index + 31),
      Array.from({ length: 15 }, (_, index) => index + 46),
      Array.from({ length: 15 }, (_, index) => index + 61)
    ];

    const card = {
      B: [],
      I: [],
      N: [],
      G: [],
      O: []
    };

    Object.keys(card).forEach((key, colIndex) => {
      const shuffled = [...columns[colIndex]].sort(() => Math.random() - 0.5);
      const selected = shuffled.slice(0, 5);

      if (key === "N") {
        selected[2] = "FREE";
      }

      card[key] = selected;
    });

    return card;
  }

  static async purchaseTicket({ game_id, user_id }) {
    console.log("DEBUG purchaseTicket payload:", { game_id, user_id });
    console.log("DEBUG purchaseTicket game_id:", game_id, "user_id:", user_id);

    if (!game_id || !user_id) {
      const error = new Error("game_id and user_id are required");
      error.statusCode = 400;
      throw error;
    }

    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      const gameQueryParams = [game_id];
      console.log("DEBUG game select query params:", gameQueryParams);
      const gameResult = await client.query(
        `
        SELECT * FROM games WHERE id = $1
        `,
        gameQueryParams
      );
      console.log("DEBUG game select result:", gameResult.rows);

      const game = gameResult.rows[0];

      if (!game) {
        console.log(`Game with ID ${game_id} does not exist.`);
        const error = new Error("Game not found");
        error.statusCode = 404;
        throw error;
      }

      if (!["active", "pending"].includes(game.status)) {
        const error = new Error("Game is not open for ticket purchase");
        error.statusCode = 400;
        throw error;
      }

      const maxPlayers = Number(game.max_players || 0);

      // Compute current players by counting tickets for the game (schema has no current_players column)
      const ticketsCountResult = await client.query(
        `
        SELECT COUNT(*)::int AS count FROM tickets WHERE game_id = $1
        `,
        [game_id]
      );
      const currentPlayers = Number(ticketsCountResult.rows[0]?.count || 0);
      console.log("DEBUG current players (tickets count):", currentPlayers);

      if (currentPlayers >= maxPlayers) {
        const error = new Error("Game is full");
        error.statusCode = 400;
        throw error;
      }

      const walletResult = await client.query(
        `
        SELECT * FROM wallets WHERE user_id = $1
        `,
        [user_id]
      );

      const wallet = walletResult.rows[0];

      if (!wallet) {
        const error = new Error("Wallet not found");
        error.statusCode = 404;
        throw error;
      }

      const entryFee = Number(game.entry_fee || 0);

      if (Number(wallet.balance) < entryFee) {
        const error = new Error("Insufficient wallet balance");
        error.statusCode = 400;
        throw error;
      }

      const updatedWallet = await client.query(
        `
        UPDATE wallets
        SET balance = balance - $1, updated_at = CURRENT_TIMESTAMP
        WHERE user_id = $2
        RETURNING *
        `,
        [entryFee, user_id]
      );

      const ticket = await Ticket.create(
        {
          game_id,
          user_id,
          price: entryFee,
          status: "active"
        },
        client
      );

      const cardData = this.generateBingoCard();
      const card = await BingoCard.createCard(
        {
          game_id,
          user_id,
          ticket_id: ticket.id,
          numbers: cardData
        },
        client
      );

      const transactionResult = await client.query(
        `
        INSERT INTO transactions
        (user_id, type, amount, reference, status)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *
        `,
        [user_id, "game_entry", entryFee, `ticket-${ticket.id}`, "completed"]
      );

      // Schema does not include current_players; update only the timestamp and return the game
      const updatedGame = await client.query(
        `
        UPDATE games
        SET updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
        RETURNING *
        `,
        [game_id]
      );

      await client.query("COMMIT");

      return {
        ticket,
        card,
        wallet: updatedWallet.rows[0],
        transaction: transactionResult.rows[0],
        game: updatedGame.rows[0]
      };
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }

  static async getTickets(user_id) {
    if (!user_id) {
      const error = new Error("user_id is required");
      error.statusCode = 400;
      throw error;
    }

    return Ticket.findByUser(user_id);
  }

  static async getTicketById(id) {
    if (!id) {
      const error = new Error("ticket id is required");
      error.statusCode = 400;
      throw error;
    }

    const ticket = await Ticket.findById(id);

    if (!ticket) {
      const error = new Error("Ticket not found");
      error.statusCode = 404;
      throw error;
    }

    return ticket;
  }

  static async getTicketsByGame(game_id) {
    if (!game_id) {
      const error = new Error("game_id is required");
      error.statusCode = 400;
      throw error;
    }

    return Ticket.findByGame(game_id);
  }

  static async validateTicket(ticketId) {
    if (!ticketId) {
      const error = new Error("ticketId is required");
      error.statusCode = 400;
      throw error;
    }

    const ticket = await Ticket.findById(ticketId);

    if (!ticket) {
      const error = new Error("Ticket not found");
      error.statusCode = 404;
      throw error;
    }

    const updatedTicket = await Ticket.updateStatus(ticket.id, "validated");

    return updatedTicket;
  }
}

module.exports = TicketService;
