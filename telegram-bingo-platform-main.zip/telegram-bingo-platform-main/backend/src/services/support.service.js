const pool = require("../config/database");

class SupportService {
  static async createTicket(payload) {
    const { user_id, subject, message, status = "open" } = payload || {};

    if (!user_id || !subject || !message) {
      const error = new Error("user_id, subject, and message are required");
      error.statusCode = 400;
      throw error;
    }

    const result = await pool.query(
      `
      INSERT INTO support_tickets
      (user_id, subject, message, status)
      VALUES ($1, $2, $3, $4)
      RETURNING *
      `,
      [user_id, subject, message, status]
    );

    return result.rows[0];
  }

  static async updateTicket(id, payload) {
    const { subject, message, status } = payload || {};

    if (!id) {
      const error = new Error("ticket id is required");
      error.statusCode = 400;
      throw error;
    }

    const result = await pool.query(
      `
      UPDATE support_tickets
      SET subject = COALESCE($1, subject),
          message = COALESCE($2, message),
          status = COALESCE($3, status)
      WHERE id = $4
      RETURNING *
      `,
      [subject, message, status, id]
    );

    if (!result.rows[0]) {
      const error = new Error("Support ticket not found");
      error.statusCode = 404;
      throw error;
    }

    return result.rows[0];
  }

  static async closeTicket(id) {
    if (!id) {
      const error = new Error("ticket id is required");
      error.statusCode = 400;
      throw error;
    }

    const result = await pool.query(
      `
      UPDATE support_tickets
      SET status = 'closed'
      WHERE id = $1
      RETURNING *
      `,
      [id]
    );

    if (!result.rows[0]) {
      const error = new Error("Support ticket not found");
      error.statusCode = 404;
      throw error;
    }

    return result.rows[0];
  }

  static async getAllTickets() {
    const result = await pool.query(
      `
      SELECT *
      FROM support_tickets
      ORDER BY id DESC
      `
    );

    return result.rows;
  }
}

module.exports = SupportService;
