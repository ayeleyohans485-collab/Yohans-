const User = require("../models/User");
const Transaction = require("../models/Transaction");
const Wallet = require("../models/Wallet");
const Game = require("../models/Game");
const Ticket = require("../models/Ticket");
const pool = require("../config/database");

class ReportService {
  static async getDashboardStats() {
    const [users, games, transactions, wallets] = await Promise.all([
      User.findAll(),
      Game.findAll(),
      pool.query("SELECT COUNT(*)::int AS count, COALESCE(SUM(amount), 0)::numeric AS revenue FROM transactions WHERE status = 'completed'"),
      pool.query("SELECT COALESCE(SUM(balance), 0)::numeric AS total_balance FROM wallets")
    ]);

    return {
      totalUsers: users.length,
      totalGames: games.length,
      activeGames: games.filter((game) => game.status === "active").length,
      completedTransactions: Number(transactions.rows[0]?.count || 0),
      totalRevenue: Number(transactions.rows[0]?.revenue || 0),
      totalWalletBalance: Number(wallets.rows[0]?.total_balance || 0)
    };
  }

  static async getDailyReport() {
    const result = await pool.query(
      `
      SELECT DATE(created_at) AS date, COUNT(*)::int AS count, COALESCE(SUM(amount), 0)::numeric AS revenue
      FROM transactions
      WHERE status = 'completed' AND created_at >= CURRENT_DATE - INTERVAL '30 days'
      GROUP BY DATE(created_at)
      ORDER BY DATE(created_at) DESC
      `
    );

    return result.rows;
  }

  static async getWeeklyReport() {
    const result = await pool.query(
      `
      SELECT DATE_TRUNC('week', created_at) AS week, COUNT(*)::int AS count, COALESCE(SUM(amount), 0)::numeric AS revenue
      FROM transactions
      WHERE status = 'completed' AND created_at >= CURRENT_DATE - INTERVAL '90 days'
      GROUP BY DATE_TRUNC('week', created_at)
      ORDER BY DATE_TRUNC('week', created_at) DESC
      `
    );

    return result.rows;
  }

  static async getMonthlyReport() {
    const result = await pool.query(
      `
      SELECT DATE_TRUNC('month', created_at) AS month, COUNT(*)::int AS count, COALESCE(SUM(amount), 0)::numeric AS revenue
      FROM transactions
      WHERE status = 'completed' AND created_at >= CURRENT_DATE - INTERVAL '365 days'
      GROUP BY DATE_TRUNC('month', created_at)
      ORDER BY DATE_TRUNC('month', created_at) DESC
      `
    );

    return result.rows;
  }

  static async getRevenueReport() {
    const result = await pool.query(
      `
      SELECT type, COUNT(*)::int AS count, COALESCE(SUM(amount), 0)::numeric AS revenue
      FROM transactions
      WHERE status = 'completed'
      GROUP BY type
      ORDER BY revenue DESC
      `
    );

    return result.rows;
  }

  static async getUserReport() {
    const result = await pool.query(
      `
      SELECT u.id, u.username, u.first_name, u.telegram_id, COUNT(t.id)::int AS ticket_count
      FROM users u
      LEFT JOIN tickets t ON t.user_id = u.id
      GROUP BY u.id, u.username, u.first_name, u.telegram_id
      ORDER BY ticket_count DESC, u.id DESC
      `
    );

    return result.rows;
  }
}

module.exports = ReportService;
