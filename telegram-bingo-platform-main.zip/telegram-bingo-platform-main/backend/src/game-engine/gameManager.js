'use strict';

const pool = require("../config/database");
const NumberGenerator = require("./number.generator");
const Game = require("../models/Game");

class GameManager {
  constructor() {
    this.generators = new Map();
  }

  async getActiveGames() {
    return Game.getActiveGames();
  }

  async getDrawHistory(gameId) {
    const result = await pool.query(
      `
      SELECT number, letter, draw_order AS order
      FROM game_draws
      WHERE game_id = $1
      ORDER BY draw_order ASC
      `,
      [gameId]
    );

    return result.rows;
  }

  async recordDraw(gameId, draw) {
    const result = await pool.query(
      `
      INSERT INTO game_draws (game_id, number, letter, draw_order)
      VALUES ($1, $2, $3, $4)
      RETURNING *
      `,
      [gameId, draw.number, draw.letter, draw.order]
    );

    return result.rows[0];
  }

  _createGenerator() {
    if (NumberGenerator && NumberGenerator.NumberGenerator) {
      return new NumberGenerator.NumberGenerator();
    }

    return NumberGenerator;
  }

  async _ensureGenerator(gameId) {
    let generator = this.generators.get(gameId);

    if (!generator) {
      generator = this._createGenerator();
      const draws = await this.getDrawHistory(gameId);

      if (draws.length > 0 && typeof generator.loadDrawnNumbers === "function") {
        generator.loadDrawnNumbers(draws);
      }

      this.generators.set(gameId, generator);
    }

    return generator;
  }

  async drawNextNumber(gameId) {
    const generator = await this._ensureGenerator(gameId);

    if (generator.isFinished()) {
      return null;
    }

    const draw = generator.draw();
    await this.recordDraw(gameId, draw);

    return draw;
  }

  async completeGame(gameId) {
    return Game.update(gameId, { status: "completed" });
  }

  clearGenerator(gameId) {
    this.generators.delete(gameId);
  }
}

module.exports = new GameManager();
