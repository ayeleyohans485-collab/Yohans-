'use strict';

const pool = require("../config/database");
const Wallet = require("../models/Wallet");
const Transaction = require("../models/Transaction");
const Ticket = require("../models/Ticket");
const Game = require("../models/Game");

class PrizeDistributor {
  static async distributePrizes(gameId, winners, prizeAmount) {
    if (!Array.isArray(winners) || winners.length === 0) {
      return [];
    }

    const prizePerWinner = Number(prizeAmount) / winners.length;
    const distributed = [];
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      for (const winner of winners) {
        const userId = winner.ticket.user_id;
        const ticketId = winner.ticket.id;
        const updatedWallet = await Wallet.update(userId, { balance: prizePerWinner }, client);

        const transaction = await Transaction.create(
          {
            user_id: userId,
            type: "prize",
            amount: prizePerWinner,
            reference: `prize-game-${gameId}-ticket-${ticketId}`,
            status: "completed"
          },
          client
        );

        await Ticket.updateStatus(ticketId, "won", client);

        distributed.push({
          ticket: winner.ticket,
          wallet: updatedWallet,
          transaction
        });
      }

      await Game.update(gameId, { status: "completed" });
      await client.query("COMMIT");
      return distributed;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}

module.exports = PrizeDistributor;
