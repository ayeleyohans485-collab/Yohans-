'use strict';

// NumberGenerator: draws unique Bingo numbers 1..75 and assigns Bingo letters.
class NumberGenerator {
  constructor() {
    this._min = 1;
    this._max = 75;
    this.reset();
  }

  // Reset the generator to initial state and shuffle the draw order
  reset() {
    // build array [1..75]
    this._remaining = Array.from({ length: this._max - this._min + 1 }, (_, i) => i + this._min);
    this._shuffle(this._remaining);
    this._drawn = []; // array of { number, letter, order }
    this._drawnSet = new Set(); // quick lookup to prevent duplicates
  }

  loadDrawnNumbers(draws) {
    if (!Array.isArray(draws)) {
      throw new TypeError("draws must be an array");
    }

    this.reset();

    const drawnNumbers = new Set();
    this._drawn = draws.map((draw) => {
      if (!draw || typeof draw.number !== "number") {
        throw new TypeError("Invalid draw record");
      }
      const entry = {
        number: draw.number,
        letter: draw.letter || this.getLetter(draw.number),
        order: draw.order
      };
      drawnNumbers.add(draw.number);
      return entry;
    });

    this._drawnSet = drawnNumbers;
    this._remaining = this._remaining.filter((value) => !this._drawnSet.has(value));
  }

  // Fisher-Yates shuffle
  _shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  // Draw the next number. Returns object { number, letter, order } or null when finished.
  draw() {
    if (this.isFinished()) return null;

    const number = this._remaining.pop();

    if (this._drawnSet.has(number)) {
      // This should never happen; defensive check
      throw new Error(`Duplicate number drawn: ${number}`);
    }

    const order = this._drawn.length + 1;
    const letter = this.getLetter(number);

    const entry = { number, letter, order };

    this._drawn.push(entry);
    this._drawnSet.add(number);

    return entry;
  }

  // Map a number to its Bingo letter
  getLetter(number) {
    if (typeof number !== 'number' || Number.isNaN(number)) {
      throw new TypeError('number must be a valid Number');
    }
    if (number < this._min || number > this._max) {
      throw new RangeError(`number must be between ${this._min} and ${this._max}`);
    }

    if (number <= 15) return 'B';
    if (number <= 30) return 'I';
    if (number <= 45) return 'N';
    if (number <= 60) return 'G';
    return 'O';
  }

  // Return a shallow copy of drawn numbers in order
  getDrawnNumbers() {
    return this._drawn.slice();
  }

  // True when all numbers have been drawn
  isFinished() {
    return this._remaining.length === 0;
  }
}

const generator = new NumberGenerator();
generator.NumberGenerator = NumberGenerator;
module.exports = generator;
