'use strict';

const GameManager = require("./gameManager");
const WinnerChecker = require("./winnerChecker");
const PrizeDistributor = require("./prizeDistributor");
const Game = require("../models/Game");

class Scheduler {
  constructor() {
    this.timer = null;
    this.intervalMs = 30 * 1000; // default 30 seconds
    this.isRunning = false;
  }

  async _processGame(game) {
    try {
      if (game.status !== "active") {
        return;
      }

      const draw = await GameManager.drawNextNumber(game.id);
      if (!draw) {
        await Game.update(game.id, { status: "completed" });
        return;
      }

      const { winners } = await WinnerChecker.findWinners(game.id);
      if (winners.length > 0) {
        await PrizeDistributor.distributePrizes(game.id, winners, game.prize);
      }
    } catch (error) {
      console.error(`Scheduler error processing game ${game.id}:`, error.message);
    }
  }

  async _tick() {
    try {
      const games = await Game.getActiveGames();
      await Promise.all(games.map((game) => this._processGame(game)));
    } catch (error) {
      console.error("Scheduler tick failed:", error.message);
    }
  }

  start(intervalMs = 30000) {
    if (this.isRunning) {
      return;
    }

    this.intervalMs = Number(intervalMs) || this.intervalMs;
    this.isRunning = true;
    this.timer = setInterval(() => this._tick(), this.intervalMs);
    console.log(`✅ Game scheduler started with interval ${this.intervalMs}ms`);
  }

  stop() {
    if (!this.isRunning) {
      return;
    }

    clearInterval(this.timer);
    this.timer = null;
    this.isRunning = false;
    console.log("⏹️ Game scheduler stopped");
  }
}

module.exports = new Scheduler();
