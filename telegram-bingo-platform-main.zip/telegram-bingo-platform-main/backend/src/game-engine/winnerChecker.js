'use strict';

const pool = require("../config/database");
const Ticket = require("../models/Ticket");
const BingoCard = require("../models/BingoCard");
const Game = require("../models/Game");

class WinnerChecker {
  static async getDrawnNumbers(gameId) {
    const result = await pool.query(
      `
      SELECT number
      FROM game_draws
      WHERE game_id = $1
      ORDER BY draw_order ASC
      `,
      [gameId]
    );

    return result.rows.map((row) => row.number);
  }

  static async getActiveTickets(gameId) {
    return Ticket.findByGame(gameId);
  }

  static async getBingoCard(ticketId) {
    const cards = await BingoCard.findByTicket(ticketId);
    return cards[0] || null;
  }

  static _checkLine(numbers, drawnSet) {
    return numbers.every((value) => value === "FREE" || drawnSet.has(value));
  }

  static _buildColumns(card) {
    return ["B", "I", "N", "G", "O"].map((column) => card[column] || []);
  }

  static _buildRows(card) {
    const rows = [];
    for (let rowIndex = 0; rowIndex < 5; rowIndex++) {
      rows.push([
        card.B[rowIndex],
        card.I[rowIndex],
        card.N[rowIndex],
        card.G[rowIndex],
        card.O[rowIndex]
      ]);
    }
    return rows;
  }

  static _buildDiagonals(card) {
    return [
      [card.B[0], card.I[1], card.N[2], card.G[3], card.O[4]],
      [card.B[4], card.I[3], card.N[2], card.G[1], card.O[0]]
    ];
  }

  static _isWinningCard(card, drawnNumbers) {
    const drawnSet = new Set(drawnNumbers);
    const rows = this._buildRows(card);
    const columns = this._buildColumns(card);
    const diagonals = this._buildDiagonals(card);

    if (rows.some((row) => this._checkLine(row, drawnSet))) {
      return true;
    }

    if (columns.some((col) => this._checkLine(col, drawnSet))) {
      return true;
    }

    if (diagonals.some((diag) => this._checkLine(diag, drawnSet))) {
      return true;
    }

    return false;
  }

  static async findWinners(gameId) {
    const drawnNumbers = await this.getDrawnNumbers(gameId);
    const tickets = await this.getActiveTickets(gameId);

    const winners = [];
    const loserTickets = [];

    for (const ticket of tickets) {
      const card = await this.getBingoCard(ticket.id);
      if (!card || !card.numbers) {
        loserTickets.push(ticket);
        continue;
      }

      const cardNumbers = typeof card.numbers === "string" ? JSON.parse(card.numbers) : card.numbers;
      if (this._isWinningCard(cardNumbers, drawnNumbers)) {
        winners.push({ ticket, card: cardNumbers });
      } else {
        loserTickets.push(ticket);
      }
    }

    return { winners, loserTickets };
  }

  static async getFirstWinner(gameId) {
    const result = await this.findWinners(gameId);
    return result.winners[0] || null;
  }

  static async hasWinner(gameId) {
    const result = await this.findWinners(gameId);
    return result.winners.length > 0;
  }
}

module.exports = WinnerChecker;
