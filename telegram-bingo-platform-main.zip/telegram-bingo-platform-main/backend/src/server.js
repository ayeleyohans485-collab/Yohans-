require("dotenv").config();

const app = require("./app");

// Initialize database connection
require("./config/database");
const scheduler = require("./game-engine/scheduler");

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
  scheduler.start();
});