const AuthService = require("../../services/auth.service");

class AuthController {
  static async register(req, res) {
    try {
      const { telegram_id, username, first_name, phone } = req.body || {};

      const result = await AuthService.registerTelegramUser({
        telegram_id,
        username,
        first_name,
        phone
      });

      return res.status(result.created ? 201 : 200).json({
        success: true,
        message: result.created ? "User registered successfully" : "User authenticated successfully",
        data: result.user
      });
    } catch (error) {
      console.error("Auth register error:", error);

      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to register user"
      });
    }
  }

  static async me(req, res) {
    try {
      const telegramId = req.query.telegram_id || req.headers["x-telegram-id"] || req.user?.telegram_id;

      if (!telegramId) {
        return res.status(400).json({
          success: false,
          message: "telegram_id is required"
        });
      }

      const user = await AuthService.getUserProfile(telegramId);

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      return res.status(200).json({
        success: true,
        data: user
      });
    } catch (error) {
      console.error("Auth me error:", error);

      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch user"
      });
    }
  }
}

module.exports = AuthController;
