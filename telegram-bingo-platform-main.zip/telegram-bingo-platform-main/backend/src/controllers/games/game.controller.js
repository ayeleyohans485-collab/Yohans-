const GameService = require("../../services/game.service");

class GameController {
  static async create(req, res) {
    try {
      const game = await GameService.createGame(req.body || {});

      return res.status(201).json({
        success: true,
        message: "Game created successfully",
        data: game
      });
    } catch (error) {
      console.error("Game create error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to create game"
      });
    }
  }

  static async list(req, res) {
    try {
      const games = await GameService.getGames();

      return res.status(200).json({
        success: true,
        data: games
      });
    } catch (error) {
      console.error("Game list error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch games"
      });
    }
  }

  static async getGame(req, res) {
    try {
      const { id } = req.params;
      const game = await GameService.getGame(id);

      return res.status(200).json({
        success: true,
        data: game
      });
    } catch (error) {
      console.error("Game getGame error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch game"
      });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;
      const game = await GameService.updateGame(id, req.body || {});

      return res.status(200).json({
        success: true,
        message: "Game updated successfully",
        data: game
      });
    } catch (error) {
      console.error("Game update error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to update game"
      });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;
      const game = await GameService.deleteGame(id);

      return res.status(200).json({
        success: true,
        message: "Game deleted successfully",
        data: game
      });
    } catch (error) {
      console.error("Game delete error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to delete game"
      });
    }
  }

  static async getActive(req, res) {
    try {
      const games = await GameService.getActiveGames();

      return res.status(200).json({
        success: true,
        data: games
      });
    } catch (error) {
      console.error("Game getActive error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch active games"
      });
    }
  }

  static async getUpcoming(req, res) {
    try {
      const games = await GameService.getUpcomingGames();

      return res.status(200).json({
        success: true,
        data: games
      });
    } catch (error) {
      console.error("Game getUpcoming error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch upcoming games"
      });
    }
  }
}

module.exports = GameController;
