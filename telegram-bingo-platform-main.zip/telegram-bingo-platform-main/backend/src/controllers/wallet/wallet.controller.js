const WalletService = require("../../services/wallet.service");

class WalletController {
  static async getBalance(req, res) {
    try {
      const userId = req.params.userId || req.query.user_id || req.user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "user_id is required"
        });
      }

      const wallet = await WalletService.getBalance(userId);

      return res.status(200).json({
        success: true,
        data: wallet
      });
    } catch (error) {
      console.error("Wallet balance error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch wallet balance"
      });
    }
  }

  static async deposit(req, res) {
    try {
      const userId = req.params.userId || req.body.user_id || req.user?.id;
      const { amount, reference } = req.body || {};

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "user_id is required"
        });
      }

      if (amount === undefined || amount === null || amount === "") {
        return res.status(400).json({
          success: false,
          message: "amount is required"
        });
      }

      const wallet = await WalletService.deposit(userId, amount, reference);

      return res.status(200).json({
        success: true,
        message: "Deposit completed successfully",
        data: wallet
      });
    } catch (error) {
      console.error("Wallet deposit error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to process deposit"
      });
    }
  }

  static async withdraw(req, res) {
    try {
      const userId = req.params.userId || req.body.user_id || req.user?.id;
      const { amount, reference } = req.body || {};

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "user_id is required"
        });
      }

      if (amount === undefined || amount === null || amount === "") {
        return res.status(400).json({
          success: false,
          message: "amount is required"
        });
      }

      const wallet = await WalletService.withdraw(userId, amount, reference);

      return res.status(200).json({
        success: true,
        message: "Withdrawal completed successfully",
        data: wallet
      });
    } catch (error) {
      console.error("Wallet withdraw error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to process withdrawal"
      });
    }
  }

  static async history(req, res) {
    try {
      const userId = req.params.userId || req.query.user_id || req.user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "user_id is required"
        });
      }

      const transactions = await WalletService.getTransactionHistory(userId);

      return res.status(200).json({
        success: true,
        data: transactions
      });
    } catch (error) {
      console.error("Wallet history error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch transaction history"
      });
    }
  }
}

module.exports = WalletController;
