const User = require("../../models/User");
const Game = require("../../models/Game");
const Transaction = require("../../models/Transaction");
const Wallet = require("../../models/Wallet");
const pool = require("../../config/database");

class AdminController {
  static async dashboard(req, res) {
    try {
      const [users, games, transactions, wallets] = await Promise.all([
        User.findAll(),
        Game.findAll(),
        pool.query("SELECT COUNT(*)::int AS count, COALESCE(SUM(amount), 0)::numeric AS revenue FROM transactions WHERE status = 'completed'"),
        pool.query("SELECT COALESCE(SUM(balance), 0)::numeric AS total_balance FROM wallets")
      ]);

      return res.status(200).json({
        success: true,
        data: {
          totalUsers: users.length,
          totalGames: games.length,
          activeGames: games.filter((game) => game.status === "active").length,
          completedTransactions: Number(transactions.rows[0]?.count || 0),
          totalRevenue: Number(transactions.rows[0]?.revenue || 0),
          totalWalletBalance: Number(wallets.rows[0]?.total_balance || 0)
        }
      });
    } catch (error) {
      console.error("Admin dashboard error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch admin dashboard"
      });
    }
  }

  static async manageUsers(req, res) {
    try {
      const users = await User.findAll();

      return res.status(200).json({
        success: true,
        data: users
      });
    } catch (error) {
      console.error("Admin manageUsers error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch users"
      });
    }
  }

  static async manageGames(req, res) {
    try {
      const games = await Game.findAll();

      return res.status(200).json({
        success: true,
        data: games
      });
    } catch (error) {
      console.error("Admin manageGames error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch games"
      });
    }
  }

  static async managePayments(req, res) {
    try {
      const transactions = await pool.query(
        `
        SELECT *
        FROM transactions
        ORDER BY id DESC
        `
      );

      return res.status(200).json({
        success: true,
        data: transactions.rows
      });
    } catch (error) {
      console.error("Admin managePayments error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch payments"
      });
    }
  }

  static async systemSettings(req, res) {
    try {
      return res.status(200).json({
        success: true,
        data: {
          maintenanceMode: false,
          allowRegistrations: true,
          allowDeposits: true,
          allowWithdrawals: true
        }
      });
    } catch (error) {
      console.error("Admin systemSettings error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch system settings"
      });
    }
  }
}

module.exports = AdminController;
