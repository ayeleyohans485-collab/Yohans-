const TicketService = require("../../services/ticket.service");

class TicketController {
  static async purchase(req, res) {
    try {
      const { game_id, user_id } = req.body || {};
      const result = await TicketService.purchaseTicket({ game_id, user_id });

      return res.status(201).json({
        success: true,
        message: "Ticket purchased successfully",
        data: result
      });
    } catch (error) {
      console.error("Ticket purchase error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to purchase ticket"
      });
    }
  }

  static async getByUser(req, res) {
    try {
      const { userId } = req.params;
      const tickets = await TicketService.getTickets(userId);

      return res.status(200).json({
        success: true,
        data: tickets
      });
    } catch (error) {
      console.error("Ticket getByUser error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch tickets"
      });
    }
  }

  static async getByGame(req, res) {
    try {
      const { gameId } = req.params;
      const tickets = await TicketService.getTicketsByGame(gameId);

      return res.status(200).json({
        success: true,
        data: tickets
      });
    } catch (error) {
      console.error("Ticket getByGame error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch tickets"
      });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const ticket = await TicketService.getTicketById(id);

      return res.status(200).json({
        success: true,
        data: ticket
      });
    } catch (error) {
      console.error("Ticket getById error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch ticket"
      });
    }
  }

  static async validate(req, res) {
    try {
      const { id } = req.params;
      const ticket = await TicketService.validateTicket(id);

      return res.status(200).json({
        success: true,
        message: "Ticket validated successfully",
        data: ticket
      });
    } catch (error) {
      console.error("Ticket validate error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to validate ticket"
      });
    }
  }
}

module.exports = TicketController;
