const User = require("../../models/User");

class UserController {
  static async list(req, res) {
    try {
      const users = await User.findAll();

      return res.status(200).json({
        success: true,
        data: users
      });
    } catch (error) {
      console.error("User list error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch users"
      });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const user = await User.findById(id);

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      return res.status(200).json({
        success: true,
        data: user
      });
    } catch (error) {
      console.error("User getById error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to fetch user"
      });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;
      const updates = req.body || {};

      const existingUser = await User.findById(id);
      if (!existingUser) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      const updatedUser = await User.update(id, updates);

      return res.status(200).json({
        success: true,
        message: "User updated successfully",
        data: updatedUser
      });
    } catch (error) {
      console.error("User update error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to update user"
      });
    }
  }

  static async remove(req, res) {
    try {
      const { id } = req.params;
      const deletedUser = await User.delete(id);

      if (!deletedUser) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      return res.status(200).json({
        success: true,
        message: "User deleted successfully",
        data: deletedUser
      });
    } catch (error) {
      console.error("User delete error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to delete user"
      });
    }
  }
}

module.exports = UserController;
