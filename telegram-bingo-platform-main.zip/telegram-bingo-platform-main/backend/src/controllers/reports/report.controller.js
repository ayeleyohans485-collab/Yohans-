const ReportService = require("../../services/report.service");

class ReportController {
  static async dashboard(req, res) {
    try {
      const stats = await ReportService.getDashboardStats();

      return res.status(200).json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error("Report dashboard error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch dashboard statistics"
      });
    }
  }

  static async daily(req, res) {
    try {
      const report = await ReportService.getDailyReport();

      return res.status(200).json({
        success: true,
        data: report
      });
    } catch (error) {
      console.error("Report daily error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch daily report"
      });
    }
  }

  static async weekly(req, res) {
    try {
      const report = await ReportService.getWeeklyReport();

      return res.status(200).json({
        success: true,
        data: report
      });
    } catch (error) {
      console.error("Report weekly error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch weekly report"
      });
    }
  }

  static async monthly(req, res) {
    try {
      const report = await ReportService.getMonthlyReport();

      return res.status(200).json({
        success: true,
        data: report
      });
    } catch (error) {
      console.error("Report monthly error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch monthly report"
      });
    }
  }

  static async revenue(req, res) {
    try {
      const report = await ReportService.getRevenueReport();

      return res.status(200).json({
        success: true,
        data: report
      });
    } catch (error) {
      console.error("Report revenue error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch revenue report"
      });
    }
  }

  static async users(req, res) {
    try {
      const report = await ReportService.getUserReport();

      return res.status(200).json({
        success: true,
        data: report
      });
    } catch (error) {
      console.error("Report users error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch user report"
      });
    }
  }
}

module.exports = ReportController;
