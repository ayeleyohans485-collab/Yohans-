const SupportService = require("../../services/support.service");

class SupportController {
  static async create(req, res) {
    try {
      const ticket = await SupportService.createTicket(req.body || {});

      return res.status(201).json({
        success: true,
        message: "Support ticket created successfully",
        data: ticket
      });
    } catch (error) {
      console.error("Support create error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to create support ticket"
      });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;
      const ticket = await SupportService.updateTicket(id, req.body || {});

      return res.status(200).json({
        success: true,
        message: "Support ticket updated successfully",
        data: ticket
      });
    } catch (error) {
      console.error("Support update error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to update support ticket"
      });
    }
  }

  static async close(req, res) {
    try {
      const { id } = req.params;
      const ticket = await SupportService.closeTicket(id);

      return res.status(200).json({
        success: true,
        message: "Support ticket closed successfully",
        data: ticket
      });
    } catch (error) {
      console.error("Support close error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to close support ticket"
      });
    }
  }

  static async list(req, res) {
    try {
      const tickets = await SupportService.getAllTickets();

      return res.status(200).json({
        success: true,
        data: tickets
      });
    } catch (error) {
      console.error("Support list error:", error);
      return res.status(error.statusCode || 500).json({
        success: false,
        message: error.message || "Failed to fetch support tickets"
      });
    }
  }
}

module.exports = SupportController;
