const fs = require("fs");
const path = require("path");
const pool = require("../config/database");

async function migrate() {
    try {

        await pool.query(`
            CREATE TABLE IF NOT EXISTS migrations (
                id SERIAL PRIMARY KEY,
                filename VARCHAR(255) UNIQUE NOT NULL,
                executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        const schemaPath = path.join(
            __dirname,
            "../../../database/schema"
        );

        const files = fs
            .readdirSync(schemaPath)
            .filter(file => file.endsWith(".sql"))
            .sort();


        for (const file of files) {

            const check = await pool.query(
                "SELECT * FROM migrations WHERE filename = $1",
                [file]
            );


            if (check.rows.length > 0) {
                console.log(`${file} already executed ⏭️`);
                continue;
            }


            console.log(`Running ${file}`);


            const sql = fs.readFileSync(
                path.join(schemaPath, file),
                "utf8"
            );


            await pool.query(sql);


            await pool.query(
                "INSERT INTO migrations(filename) VALUES($1)",
                [file]
            );


            console.log(`${file} completed ✅`);
        }


        console.log("Database migration finished 🚀");

        process.exit();

    } catch(error) {

        console.error(
            "Migration failed ❌",
            error
        );

        process.exit(1);
    }
}


migrate();