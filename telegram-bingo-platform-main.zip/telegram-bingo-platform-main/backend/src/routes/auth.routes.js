const express = require("express");
const AuthController = require("../controllers/auth/auth.controller");

const router = express.Router();

router.post("/register", AuthController.register);
router.get("/profile", AuthController.me);

module.exports = router;