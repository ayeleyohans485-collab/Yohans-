const express = require("express");
const GameController = require("../controllers/games/game.controller");

const router = express.Router();

router.post("/", GameController.create);
router.get("/", GameController.list);
router.get("/active", GameController.getActive);
router.get("/upcoming", GameController.getUpcoming);
router.get("/:id", GameController.getGame);
router.put("/:id", GameController.update);
router.delete("/:id", GameController.delete);

module.exports = router;
