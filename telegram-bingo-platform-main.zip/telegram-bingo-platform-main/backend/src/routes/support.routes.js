const express = require("express");
const SupportController = require("../controllers/support/support.controller");

const router = express.Router();

router.post("/", SupportController.create);
router.put("/:id", SupportController.update);
router.post("/:id/close", SupportController.close);
router.get("/", SupportController.list);

module.exports = router;
