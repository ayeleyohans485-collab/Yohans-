const express = require("express");
const ReportController = require("../controllers/reports/report.controller");

const router = express.Router();

router.get("/dashboard", ReportController.dashboard);
router.get("/daily", ReportController.daily);
router.get("/weekly", ReportController.weekly);
router.get("/monthly", ReportController.monthly);
router.get("/revenue", ReportController.revenue);
router.get("/users", ReportController.users);

module.exports = router;
