const express = require("express");
const WalletController = require("../controllers/wallet/wallet.controller");

const router = express.Router();

router.get("/balance", WalletController.getBalance);
router.post("/deposit", WalletController.deposit);
router.post("/withdraw", WalletController.withdraw);
router.get("/transactions", WalletController.history);

module.exports = router;
