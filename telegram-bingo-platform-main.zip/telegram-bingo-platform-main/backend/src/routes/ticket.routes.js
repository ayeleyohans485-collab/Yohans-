const express = require("express");
const TicketController = require("../controllers/tickets/ticket.controller");

const router = express.Router();

router.post("/purchase", TicketController.purchase);
router.get("/user/:userId", TicketController.getByUser);
router.get("/game/:gameId", TicketController.getByGame);
router.get("/:id", TicketController.getById);
router.post("/:id/validate", TicketController.validate);

module.exports = router;
