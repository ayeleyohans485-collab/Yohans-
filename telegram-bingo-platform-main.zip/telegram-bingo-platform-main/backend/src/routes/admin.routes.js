const express = require("express");
const AdminController = require("../controllers/admin/admin.controller");

const router = express.Router();

router.get("/dashboard", AdminController.dashboard);
router.get("/users", AdminController.manageUsers);
router.get("/games", AdminController.manageGames);
router.get("/payments", AdminController.managePayments);
router.get("/settings", AdminController.systemSettings);

module.exports = router;
