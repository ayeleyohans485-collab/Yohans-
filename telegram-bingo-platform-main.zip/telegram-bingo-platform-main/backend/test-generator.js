'use strict';

const NumberGenerator = require('./src/game-engine/number.generator');

(async function runTest() {
  try {
    // Ensure clean start
    NumberGenerator.reset();

    console.log('Drawing 10 numbers...');

    const seen = new Set();
    for (let i = 0; i < 10; i++) {
      const draw = NumberGenerator.draw();
      if (!draw) {
        console.log('No more numbers to draw.');
        break;
      }

      console.log(draw);

      // Basic verifications
      if (seen.has(draw.number)) {
        console.error('Duplicate number detected:', draw.number);
      }
      seen.add(draw.number);

      const expectedLetter = NumberGenerator.getLetter(draw.number);
      if (expectedLetter !== draw.letter) {
        console.error('Letter mismatch for', draw.number, 'expected', expectedLetter, 'got', draw.letter);
      }

      // order check
      if (draw.order !== i + 1) {
        console.error('Order mismatch for', draw.number, 'expected', i + 1, 'got', draw.order);
      }
    }

    console.log('Drawn count:', NumberGenerator.getDrawnNumbers().length);
    console.log('All drawn numbers:', NumberGenerator.getDrawnNumbers());
  } catch (err) {
    console.error('Test encountered an error:', err);
    process.exitCode = 1;
  }
})();
