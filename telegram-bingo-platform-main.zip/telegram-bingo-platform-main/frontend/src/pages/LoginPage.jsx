import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function LoginPage() {
  const [telegramId, setTelegramId] = useState("");
  const [firstName, setFirstName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    if (!telegramId.trim()) {
      setError("Telegram ID is required.");
      return;
    }

    try {
      setLoading(true);
      await login({
        telegram_id: telegramId.trim(),
        first_name: firstName.trim() || undefined
      });
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || err.message || "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="center-page">
      <div className="card">
        <h1>Telegram Bingo</h1>
        <p>Sign in with your Telegram ID to continue.</p>
        <form onSubmit={handleSubmit}>
          <label htmlFor="telegramId">Telegram ID</label>
          <input
            id="telegramId"
            type="text"
            value={telegramId}
            onChange={(event) => setTelegramId(event.target.value)}
            required
          />
          <label htmlFor="firstName">Name</label>
          <input
            id="firstName"
            type="text"
            value={firstName}
            onChange={(event) => setFirstName(event.target.value)}
            placeholder="Optional"
          />
          {error && <p className="error">{error}</p>}
          <button type="submit" disabled={loading}>
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>
      </div>
    </div>
  );
}
