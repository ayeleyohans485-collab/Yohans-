import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import adminService from "../services/adminService";

export default function DashboardPage() {
  const { user } = useAuth();
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    adminService
      .getDashboard()
      .then((data) => setSummary(data))
      .catch(() => setError("Unable to load dashboard metrics."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="page-shell">
      <div className="page-header">
        <div>
          <p className="eyebrow">Dashboard</p>
          <h1>Welcome back, {user?.first_name || user?.username || "Player"}!</h1>
        </div>
      </div>

      {loading ? (
        <div className="card">Loading dashboard...</div>
      ) : error ? (
        <div className="card error-card">{error}</div>
      ) : (
        <div className="grid-3">
          <div className="card">
            <h2>Total Users</h2>
            <p>{summary.totalUsers}</p>
          </div>
          <div className="card">
            <h2>Total Games</h2>
            <p>{summary.totalGames}</p>
          </div>
          <div className="card">
            <h2>Active Games</h2>
            <p>{summary.activeGames}</p>
          </div>
          <div className="card">
            <h2>Completed Transactions</h2>
            <p>{summary.completedTransactions}</p>
          </div>
          <div className="card">
            <h2>Total Revenue</h2>
            <p>ETB {summary.totalRevenue.toFixed(2)}</p>
          </div>
          <div className="card">
            <h2>Total Wallet Balance</h2>
            <p>ETB {summary.totalWalletBalance.toFixed(2)}</p>
          </div>
        </div>
      )}
    </div>
  );
}
