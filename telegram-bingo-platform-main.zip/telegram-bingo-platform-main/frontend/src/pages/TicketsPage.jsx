export default function TicketsPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Tickets</h2>
        <p>Review ticket purchases and ticket status across games.</p>
      </section>
    </div>
  );
}
