export default function WalletPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Wallet</h2>
        <p>View balances and transaction history for platform wallets.</p>
      </section>
    </div>
  );
}
