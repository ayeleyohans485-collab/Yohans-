export default function GamesPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Games</h2>
        <p>Manage bingo games, set entry fees, and monitor active sessions.</p>
      </section>
    </div>
  );
}
