export default function PaymentsPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Payments</h2>
        <p>Track deposits, withdrawals, and payment transaction data.</p>
      </section>
    </div>
  );
}
