export default function SupportPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Support</h2>
        <p>Manage user questions, tickets, and support responses.</p>
      </section>
    </div>
  );
}
