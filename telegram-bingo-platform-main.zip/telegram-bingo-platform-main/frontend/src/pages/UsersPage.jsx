import UsersTable from "../components/UsersTable";
import useUsers from "../hooks/useUsers";

export default function UsersPage() {
  const { users, loading, error, refresh } = useUsers();

  return (
    <div className="page-shell">
      <div className="page-header">
        <div>
          <p className="eyebrow">Users</p>
          <h1>Manage Users</h1>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="button-secondary" onClick={refresh}>
            Refresh
          </button>
        </div>
      </div>

      <UsersTable users={users} loading={loading} error={error} />
    </div>
  );
}
