export default function ReportsPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Reports</h2>
        <p>View revenue, growth, and player performance reports.</p>
      </section>
    </div>
  );
}
