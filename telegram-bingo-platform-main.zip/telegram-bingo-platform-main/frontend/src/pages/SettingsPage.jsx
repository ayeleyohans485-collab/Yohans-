export default function SettingsPage() {
  return (
    <div className="page-grid">
      <section className="card">
        <h2>Settings</h2>
        <p>Configure platform settings, game defaults, and admin preferences.</p>
      </section>
    </div>
  );
}
