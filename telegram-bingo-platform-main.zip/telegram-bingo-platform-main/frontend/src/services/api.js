import axios from "axios";

const api = axios.create({
  baseURL: "/api",
  headers: {
    "Content-Type": "application/json"
  }
});

api.interceptors.request.use((config) => {
  const telegramId = localStorage.getItem("telegram_id");
  if (telegramId) {
    config.headers = {
      ...config.headers,
      "x-telegram-id": telegramId
    };
  }
  return config;
});

export default api;
