import api from "./api";

const userService = {
  // Fetch all users (admin endpoint)
  getUsers: async () => {
    const res = await api.get("/admin/users");
    return res.data.data;
  }
};

export default userService;
