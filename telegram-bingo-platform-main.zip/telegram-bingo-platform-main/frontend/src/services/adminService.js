import api from "./api";

const adminService = {
  getDashboard: async () => {
    const response = await api.get("/admin/dashboard");
    return response.data.data;
  }
};

export default adminService;
