import api from "./api";

const authService = {
  login: async ({ telegram_id }) => {
    const response = await api.post("/auth/register", { telegram_id });
    return response.data;
  },
  getProfile: async () => {
    const response = await api.get("/auth/profile");
    return response.data;
  }
};

export default authService;
