import { createContext, useContext, useEffect, useMemo, useState } from "react";
import api from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [telegramId, setTelegramId] = useState(() => localStorage.getItem("telegram_id"));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!telegramId) {
      setLoading(false);
      return;
    }

    api
      .get("/auth/profile")
      .then((response) => {
        setUser(response.data.data);
      })
      .catch(() => {
        setTelegramId(null);
        localStorage.removeItem("telegram_id");
      })
      .finally(() => setLoading(false));
  }, [telegramId]);

  const login = async ({ telegram_id, username, first_name, phone }) => {
    const response = await api.post("/auth/register", {
      telegram_id,
      username,
      first_name,
      phone
    });

    const userData = response.data?.data;

    if (!userData) {
      throw new Error("Authentication failed");
    }

    setTelegramId(String(telegram_id));
    localStorage.setItem("telegram_id", String(telegram_id));
    setUser(userData);

    return userData;
  };

  const logout = () => {
    setUser(null);
    setTelegramId(null);
    localStorage.removeItem("telegram_id");
  };

  const value = useMemo(
    () => ({ user, telegramId, loading, login, logout, isAuthenticated: Boolean(user) }),
    [user, telegramId, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
