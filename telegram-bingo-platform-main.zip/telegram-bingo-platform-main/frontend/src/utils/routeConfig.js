const routeConfig = [
  { path: "/", label: "Dashboard" },
  { path: "/users", label: "Users" },
  { path: "/wallet", label: "Wallet" },
  { path: "/games", label: "Games" },
  { path: "/tickets", label: "Tickets" },
  { path: "/payments", label: "Payments" },
  { path: "/reports", label: "Reports" },
  { path: "/support", label: "Support" },
  { path: "/settings", label: "Settings" }
];

export default routeConfig;
