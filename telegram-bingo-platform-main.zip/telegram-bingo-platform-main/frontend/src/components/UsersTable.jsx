import React, { useMemo, useState } from "react";

export default function UsersTable({ users = [], loading, error }) {
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) => {
      return (
        String(u.username || "").toLowerCase().includes(q) ||
        String(u.first_name || "").toLowerCase().includes(q) ||
        String(u.telegram_id || "").toLowerCase().includes(q)
      );
    });
  }, [users, query]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));

  const current = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page]);

  const handlePrev = () => setPage((p) => Math.max(1, p - 1));
  const handleNext = () => setPage((p) => Math.min(totalPages, p + 1));

  if (loading) return <div className="card">Loading users...</div>;
  if (error) return <div className="card error-card">{error}</div>;

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <input
          placeholder="Search by username, name, or telegram id"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setPage(1);
          }}
          style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid #e5e7eb" }}
        />
      </div>

      <div className="card">
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ textAlign: "left", borderBottom: "1px solid #e5e7eb" }}>
              <th style={{ padding: "8px 6px" }}>ID</th>
              <th style={{ padding: "8px 6px" }}>Telegram ID</th>
              <th style={{ padding: "8px 6px" }}>Username</th>
              <th style={{ padding: "8px 6px" }}>Name</th>
              <th style={{ padding: "8px 6px" }}>Joined</th>
            </tr>
          </thead>
          <tbody>
            {current.map((u) => (
              <tr key={u.id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                <td style={{ padding: "10px 6px" }}>{u.id}</td>
                <td style={{ padding: "10px 6px" }}>{u.telegram_id}</td>
                <td style={{ padding: "10px 6px" }}>{u.username || "-"}</td>
                <td style={{ padding: "10px 6px" }}>{u.first_name || "-"}</td>
                <td style={{ padding: "10px 6px" }}>{new Date(u.created_at).toLocaleString()}</td>
              </tr>
            ))}
            {current.length === 0 && (
              <tr>
                <td colSpan={5} style={{ padding: 16 }}>
                  No users found.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
          <div>
            Showing {Math.min((page - 1) * pageSize + 1, filtered.length)}-
            {Math.min(page * pageSize, filtered.length)} of {filtered.length}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={handlePrev} disabled={page === 1} className="button-secondary">
              Prev
            </button>
            <button onClick={handleNext} disabled={page === totalPages} className="button-secondary">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
