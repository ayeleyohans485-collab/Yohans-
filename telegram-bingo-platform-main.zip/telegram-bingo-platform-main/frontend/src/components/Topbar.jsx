import { useAuth } from "../context/AuthContext";

export default function Topbar() {
  const { user, logout } = useAuth();

  return (
    <header className="topbar">
      <div>
        <p className="topbar-title">Admin Dashboard</p>
      </div>
      <div className="topbar-actions">
        <span className="topbar-user">{user?.first_name || user?.username || "Administrator"}</span>
        <button className="button-secondary" onClick={logout}>
          Logout
        </button>
      </div>
    </header>
  );
}
