import { NavLink } from "react-router-dom";
import routeConfig from "../utils/routeConfig";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <strong>Telegram</strong> Bingo
      </div>
      <nav className="sidebar-nav">
        {routeConfig.map((route) => (
          <NavLink
            key={route.path}
            to={route.path}
            className={({ isActive }) =>
              `sidebar-link ${isActive ? "active" : ""}`
            }
          >
            {route.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
